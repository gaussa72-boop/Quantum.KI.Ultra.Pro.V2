import os
from flask import Flask, render_template_string, request, jsonify
from agent import MetaKIAgent
from dotenv import load_dotenv
load_dotenv()

app = Flask(__name__)

TEMPLATE = '''
<!doctype html>
<title>Meta-KI Prototype</title>
<h1>Meta-KI: Idee → Code</h1>
<form method=post action="/generate">
  <textarea name=idea rows=6 cols=60 placeholder="Beschreibe deine Idee..."></textarea><br/>
  <input type=submit value="Generiere Code">
</form>
<hr/>
<div id="output">{{output}}</div>
'''

@app.route("/", methods=["GET"])
def index():
    return render_template_string(TEMPLATE, output="")

@app.route("/generate", methods=["POST"])
def generate():
    idea = request.form.get("idea","").strip()
    if not idea:
        return render_template_string(TEMPLATE, output="Keine Idee eingegeben.")
    agent = MetaKIAgent(api_key=os.getenv('OPENAI_API_KEY'))
    code, tests = agent.generate_program(idea)
    return render_template_string(TEMPLATE, output=f"<h3>Code Vorschlag</h3><pre>{code}</pre><h3>Unit Tests</h3><pre>{tests}</pre>")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)

    import os
    import json
    # Requires openai package and an API key set in OPENAI_API_KEY
    try:
        import openai
    except Exception:
        openai = None

    class MetaKIAgent:
        """Ein einfacher Agent: Idee -> Code + Tests.
        Achtung: Dies ist ein Prototyp. Setze OPENAI_API_KEY in der Umgebung.
        """
        def __init__(self, api_key=None):
            self.api_key = api_key or os.getenv('OPENAI_API_KEY')
            if openai and self.api_key:
                openai.api_key = self.api_key

        def generate_program(self, idee:str):
            prompt = f"""Erstelle ein kleines Python-Projekt für die folgende Idee.             Gib zuerst die Dateien zurück, beginnend mit main.py, dann tests.py.            Idee:\n{idee}\n
Antwort als JSON: {{'main_py':'...','tests_py':'...'}}"""
            if openai:
                try:
                    resp = openai.Completion.create(
                        engine='text-davinci-003',
                        prompt=prompt,
                        max_tokens=800
                    )
                    text = resp.choices[0].text.strip()
                except Exception as e:
                    text = json.dumps({'main_py':f'# Fehler beim Aufruf der API: {e}','tests_py':''})
            else:
                # Fallback: template
                main = f"""# Auto-generierter Prototyp für Idee: {idee}\nprint('Hello from generated program')\n"""
                tests = """def test_placeholder():\n    assert True\n"""
                text = json.dumps({'main_py':main, 'tests_py':tests})
            # try to parse JSON from text
            try:
                data = json.loads(text)
                return data.get('main_py',''), data.get('tests_py','')
            except Exception:
                # return raw text as main
                return text, ''

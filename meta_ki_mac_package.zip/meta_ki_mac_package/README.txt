Meta-KI macOS Package
=====================

Inhalt dieses Archives:
- meta_ki_prototype/      (Python prototype + Flask UI)
- quantum_notebooks/      (Jupyter notebook demos for quantum chemistry)
- docs/                   (Architecture & Quantum-OS design)
- build_scripts/          (py2app and briefcase example scripts)
- LICENSE
- README.txt (this file)

Wichtige Hinweise:
- Du hast "macOS Catalina 10.18.7" genannt. Es gibt keine macOS 10.18. Catalina ist Version 10.15.x.
  Ich nehme an, du meinst macOS Catalina 10.15.7. Falls du ein anderes Release meinst, passe die
  Minimal-Version in Info.plist entsprechend an.
- Dieses ZIP enthält den Quellcode und Build-Skripte. Ich kann hier in dieser environment
  keine signierten, notarized .app-Bundles erstellen (py2app must be run on macOS).
  Du kannst auf deinem Mac das App-Bundle mit den beiliegenden Skripten bauen.
- Für die Meta-KI-Komponenten benötigst du einen LLM-Zugang (z.B. OpenAI API key). Setze
  die Umgebungsvariable OPENAI_API_KEY bevor du das Projekt startest.

Schnellstart (auf deinem Mac):
1) Entpacken:
   unzip meta_ki_mac_package.zip
2) Terminal -> in meta_ki_prototype:
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
3) .env konfigurieren (siehe README in meta_ki_prototype)
4) Lokaler Start (Web-UI):
   python app.py
   -> öffne http://localhost:8080 im Browser
5) App bauen (macOS, optional):
   # Für py2app:
   cd build_scripts
   ./build_py2app.sh
   # Für Briefcase (creates a .app using briefcase on macos):
   ./build_briefcase.sh

Wenn du möchtest, kann ich jetzt:
- die lauffähigen Quell-Dateien in dieses ZIP einbauen (habe ich getan),
- und die ZIP-Datei hier zum Download bereitstellen (unten).

Architektur: Meta-KI + Quantum-OS (Proof-of-Concept)
===================================================

1) Meta-KI Prototype (klassisch)
   - LLM-gestützter Agent, der Idee -> Template-Code -> Unit-Tests erzeugt
   - CI loop: sandboxed execution, pytest, feedback to LLM, versioning (git)
   - Sicherheitslayer: sandbox (Docker), resource limits, human-in-the-loop gating

2) Quantum-Integration
   - Simulations-First: use PennyLane / Qiskit on simulator for VQE / small-molecule experiments
   - Hybrid circuits: classical optimizer + parameterized quantum circuits
   - Data flow: design molecules as Hamiltonians -> VQE -> evaluate energy -> propose new candidate

3) Quantum-OS concept
   - OS-like runtime that schedules quantum jobs, manages qubit resources, and exposes high-level APIs
   - Not a conscious entity; 'awareness' is metadata + telemetry + agent-driven intent management
   - Governance: strict access control, explainable audit logs, human approval for biological tasks

4) Build & Deploy on macOS (Catalina)
   - Use py2app or Briefcase to create .app bundles.
   - Note: Signing and notarization require Apple Developer account.
   - Example Info.plist keys provided in build_scripts.

Limitations & Ethics:
 - No biological instructions are included.
 - Any medical application requires clinical trials and regulation compliance.

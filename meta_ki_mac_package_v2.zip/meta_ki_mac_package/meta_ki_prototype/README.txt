Meta-KI Prototype
-----------------
Dieses kleine Projekt startet eine Flask-Weboberfläche, in die du eine Idee schreiben kannst.
Der MetaKIAgent versucht (mittels OpenAI API) aus der Idee ein kleines Python-Projekt und Unit-Tests zu generieren.

Installation (auf macOS):
  python3 -m venv venv
  source venv/bin/activate
  pip install -r requirements.txt

Setze deine OpenAI API Key:
  cp .env.example .env
  edit .env und setze OPENAI_API_KEY

Starten:
  python app.py

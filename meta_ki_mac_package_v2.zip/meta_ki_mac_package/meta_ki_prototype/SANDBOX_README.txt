Sandbox & Security Notes
------------------------
For running generated code safely, use Docker to sandbox execution and limit resources.

Example Dockerfile:
FROM python:3.9-slim
WORKDIR /app
COPY . /app
RUN pip install -r requirements.txt
CMD ["pytest", "-q"]

Run with resource limits:
docker build -t meta-runner .
docker run --rm --cpus=0.5 --memory=256m meta-runner

Use a separate network namespace if network access is not required:
docker run --network none --rm meta-runner

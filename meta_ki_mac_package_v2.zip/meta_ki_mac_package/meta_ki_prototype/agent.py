import os
import json
import tempfile
import subprocess
import textwrap
try:
    import openai
except Exception:
    openai = None

DEFAULT_PROMPT_TEMPLATE = """You are a helpful programming assistant.
Task: Given the following idea, generate a minimal, well-documented Python project.
Requirements:
- Provide 'main.py' implementing the functionality.
- Provide 'tests.py' containing pytest unit tests.
- Keep the project small (<= 200 lines).
- At the top of each file include a one-line description comment.
Output: Return a JSON object with keys 'main_py' and 'tests_py'.
Idea: {idea}
"""

class MetaKIAgent:
    """Enhanced Meta-KI Agent: idea -> code + tests + local test-runner.
    Use OPENAI_API_KEY environment variable for API access.
    """
    def __init__(self, api_key=None, engine='gpt-4o-mini'):
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        self.engine = engine
        if openai and self.api_key:
            openai.api_key = self.api_key

    def _call_llm(self, prompt, max_tokens=1000):
        if openai and self.api_key:
            try:
                resp = openai.Completion.create(
                    engine=self.engine,
                    prompt=prompt,
                    max_tokens=max_tokens,
                    temperature=0.2
                )
                text = resp.choices[0].text.strip()
                return text
            except Exception as e:
                return json.dumps({'main_py': f'# LLM call error: {e}', 'tests_py': ''})
        # fallback deterministic template
        main = f"""# Auto-generated placeholder for idea: {prompt[:120]}\nprint('Hello from generated program')\n"""
        tests = """def test_placeholder():\n    assert True\n"""
        return json.dumps({'main_py': main, 'tests_py': tests})

    def generate_program(self, idea: str):
        prompt = DEFAULT_PROMPT_TEMPLATE.format(idea=idea)
        raw = self._call_llm(prompt)
        # attempt JSON parse
        try:
            data = json.loads(raw)
            return data.get('main_py',''), data.get('tests_py','')
        except Exception:
            # attempt to extract code blocks (naive)
            return raw, ''

    def run_tests_locally(self, main_py: str, tests_py: str):
        """Run pytest in a temporary directory and return results (stdout/stderr)."""
        with tempfile.TemporaryDirectory() as td:
            main_path = os.path.join(td, 'main.py')
            tests_path = os.path.join(td, 'tests.py')
            with open(main_path, 'w') as f:
                f.write(main_py)
            with open(tests_path, 'w') as f:
                f.write(tests_py)
            # create minimal pytest.ini to avoid warnings
            with open(os.path.join(td, 'pytest.ini'), 'w') as f:
                f.write('[pytest]\naddopts = -q\n')
            try:
                proc = subprocess.run(['pytest', td], capture_output=True, text=True, timeout=30)
                return proc.returncode, proc.stdout + '\n' + proc.stderr
            except Exception as e:
                return 2, f'Error running tests: {e}'

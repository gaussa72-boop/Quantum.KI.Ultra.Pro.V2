import os
from flask import Flask, render_template_string, request, jsonify
from agent import MetaKIAgent
from dotenv import load_dotenv
load_dotenv()

app = Flask(__name__)

TEMPLATE = '''
<!doctype html>
<title>Meta-KI Prototype</title>
<h1>Meta-KI: Idee → Code</h1>
<form method=post action="/generate">
  <textarea name=idea rows=6 cols=60 placeholder="Beschreibe deine Idee..."></textarea><br/>
  <input type=submit value="Generiere Code">
</form>
<hr/>
<div id="output">{{output}}</div>
'''

@app.route("/", methods=["GET"])
def index():
    return render_template_string(TEMPLATE, output="")

@app.route("/generate", methods=["POST"])
def generate():
    idea = request.form.get("idea","").strip()
    if not idea:
        return render_template_string(TEMPLATE, output="Keine Idee eingegeben.")
    agent = MetaKIAgent(api_key=os.getenv('OPENAI_API_KEY'))
    code, tests = agent.generate_program(idea)
    # run tests locally (note: pytest must be installed in environment)
    try:
        rc, out = agent.run_tests_locally(code, tests)
        test_result = f"Return code: {rc}\nOutput:\n{out}"
    except Exception as e:
        test_result = f"Fehler beim Testlauf: {e}"
    return render_template_string(TEMPLATE, output=f"<h3>Code Vorschlag</h3><pre>{code}</pre><h3>Unit Tests</h3><pre>{tests}</pre><h3>Test-Result</h3><pre>{test_result}</pre>")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)

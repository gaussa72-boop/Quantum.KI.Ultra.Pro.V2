#!/bin/bash
# Build, codesign and notarize helper script (run on macOS with Xcode and Apple ID)
#
# Usage:
#   ./build_and_sign.sh /path/to/MetaKI.app
#
# Requirements:
# - Xcode command line tools installed
# - An Apple Developer account
# - App-specific password for notarization (create at appleid.apple.com)
#
set -e
APP_PATH="$1"
if [ -z "$APP_PATH" ]; then
  echo "Usage: $0 /path/to/MetaKI.app"
  exit 1
fi
# Replace these with your values
DEVELOPER_ID_APP="Developer ID Application: YOUR NAME (TEAMID)"
BUNDLE_ID="com.example.metaki"
APPLE_ID="your-apple-id@example.com"
APP_SPECIFIC_PASSWORD="app-specific-password-here"  # create in appleid.apple.com

echo "Codesigning $APP_PATH..."
codesign --deep --force --verify --verbose --sign "$DEVELOPER_ID_APP" "$APP_PATH"

echo "Creating zip for notarization..."
ZIP_PATH="/tmp/metaki_app.zip"
ditto -c -k --sequesterRsrc --keepParent "$APP_PATH" "$ZIP_PATH"

echo "Submitting for notarization (this can take several minutes)..."
xcrun altool --notarize-app -f "$ZIP_PATH" --primary-bundle-id "$BUNDLE_ID" -u "$APPLE_ID" -p "$APP_SPECIFIC_PASSWORD"

echo "Check notarization status with:": 
echo "  xcrun altool --notarization-info <REQUEST_UUID> -u '$APPLE_ID' -p '<APP_SPECIFIC_PASSWORD>'"

echo "Stapling notarization ticket to app (after success):"
echo "  xcrun stapler staple '$APP_PATH'"
echo "Done."

#!/bin/bash
# Builds a macOS .app using py2app. Run this on macOS.
set -e
echo "Building with py2app (run on macOS with Python 3.8/3.9 preferred)..."
cd ../meta_ki_prototype
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt py2app
# minimal setup.py
cat > setup.py <<'PY' 
from setuptools import setup
APP = ['app.py']
OPTIONS = {'argv_emulation': True, 'packages': ['dotenv','openai','flask']}
setup(
    app=APP,
    options={'py2app': OPTIONS},
    setup_requires=['py2app'],
)
PY
python3 setup.py py2app
echo "Built dist/*.app. You may need to codesign and notarize for distribution."

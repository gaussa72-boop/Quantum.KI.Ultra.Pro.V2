#!/bin/bash
# Build with Briefcase (BeeWare). Run on macOS.
set -e
echo "Building with Briefcase (requires briefcase and Xcode installed)..."
cd ../meta_ki_prototype
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt briefcase
# Create a briefcase project (example)
cat > pyproject.toml <<'TOML'
[tool.briefcase]
project_name = "MetaKI"
formal_name = "Meta-KI Prototype"
bundle = "com.example.metaki"
version = "0.1.0"
description = "Meta-KI Prototype"
TOML
briefcase create macOS
briefcase build macOS
briefcase package macOS
echo "Briefcase build complete. Use Xcode to sign/notarize if needed."

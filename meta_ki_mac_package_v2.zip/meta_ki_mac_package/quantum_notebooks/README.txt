Quantum Demo Notebook (PennyLane / Qiskit)
-----------------------------------------
Dieses Notebook enthält:
- VQE-Beispiel (PennyLane) zur Simulation eines kleinen Moleküls (H2) auf einem Simulator
- Hinweise zum Ausführen auf lokalen Simulatoren und remote QPU (erfordert Anbieterzugang)

Install:
  pip install pennylane qiskit numpy matplotlib

Hinweis: echte Hardware-Ausführung benötigt Zugangsdaten zum jeweiligen Provider.

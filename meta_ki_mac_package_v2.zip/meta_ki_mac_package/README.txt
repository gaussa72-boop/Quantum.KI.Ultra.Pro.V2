Meta-KI macOS Package (Expanded)
=================================
This package now contains:
- Enhanced Meta-KI prototype with test-runner and sandbox notes
- PennyLane VQE notebook (vqe_h2.ipynb) runnable on local simulator
- Build scripts including a codesign & notarize helper script
- Detailed instructions below.

macOS Version Note:
You requested macOS 'Catalina 10.18.7' which does not exist. This package targets macOS Catalina 10.15.7 (10.15.x).
If you need Big Sur / Monterey / Ventura support, update LSMinimumSystemVersion in Info.plist accordingly.

Step-by-step: Local test (on Mac)
1) Unzip package:
   unzip meta_ki_mac_package.zip
2) Setup virtualenv:
   cd meta_ki_prototype
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   pip install pytest pennylane scipy   # for notebook and tests
3) Configure API key:
   cp .env.example .env
   edit .env and set OPENAI_API_KEY
4) Run the Flask UI:
   python app.py
   Open http://localhost:8080
5) Generate an idea and observe generated code + tests + local test results.

Building .app (on macOS)
- Option A: py2app (fast)
  cd build_scripts
  ./build_py2app.sh
  # result in meta_ki_prototype/dist/MetaKI.app

- Option B: Briefcase (creates macOS app project)
  cd build_scripts
  ./build_briefcase.sh
  # use Xcode to open and sign the generated project

Codesign & Notarize (on macOS)
- Use build_scripts/build_and_sign.sh /path/to/MetaKI.app
- Fill in your Developer ID, Apple ID and app-specific password in the script
- Notarization requires internet connection and Apple Developer account.

Security
- Never run generated code without sandboxing if you don't trust it.
- Use Docker with `--network none` and resource limits for safe execution.

If you want, I can:
- further tailor the LLM prompts for your style (German/poetic/technical)
- add UI features (save projects, git integration, versioning)
- prepare an automated installer script for macOS (pkg or dmg) — note: signing required.

Download the updated ZIP in the link provided by the assistant UI.
